package Lab1;
import java.util.Scanner;
public class Exercise4 {
	boolean checkNumber(int n){
		boolean result=true;
		//int count=0;
		while(n!=1)
		{
			if(n%2 !=0)
				result=false;
			n=n/2;
		}
		return result;
	}
	@SuppressWarnings("resource")
	public static void main(String[] args)
	{
		System.out.println("Enter n value");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Exercise4 e=new Exercise4();
		System.out.println(e.checkNumber(n));	
	}
}
