package Lab1;
import java.util.Scanner;

public class Exercise2 {
	int calculateDifference(int n)
	{
		int sum,firstterm,secondterm;
		
		firstterm=(n*(n+1)*((2*n)+1))/6;
		secondterm=(n*(n+1)*n*(n+1))/4;
		
		sum=firstterm-secondterm;
		
		return sum;
	}
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		
		System.out.println("Enter n value");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Exercise2 e=new Exercise2();
		System.out.println(e.calculateDifference(n));		
	}
}
