package Lab1;

import java.util.Scanner;

public class Exercise1 {
	int  calculateSum(int n)
	{
		int sum=0,i=0;
		for(i=0;i<(n+1);i++)
		{
			if(i%3 == 0 ||i%5==0 )
			{
				sum+=i;
			}
		}
		return sum;
	}
	@SuppressWarnings("resource")
	public static void main(String[] args)
	{
		System.out.println("Enter n value");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Exercise1 e=new Exercise1();
		System.out.println(e.calculateSum(n));
	}

}
