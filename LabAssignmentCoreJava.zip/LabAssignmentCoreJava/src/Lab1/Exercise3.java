package Lab1;
import java.util.Scanner;
public class Exercise3 {
	boolean checkNumber(int number)
	{
		boolean result = true;
		int rem;
		while(number!=0)
		{
			rem= number%10;
			number=number/10;
			if(rem<=number%10)
			{
				result=false;
				break;
			}
			else 
				result=true;
		}
		return result;
	}
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		
		System.out.println("Enter number");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Exercise3 e=new Exercise3();
		if(e.checkNumber(n))
			System.out.println("Incresing No");
		else 
			System.out.println("Not Increasing No");
	}
}
