package Lab2;

public class Video extends MediaItem{
	
	private int dateOfDirector;
	private String genre;
	private int  yrofRelease;
	public int getDateOfDirector() {
		return dateOfDirector;
	}
	public void setDateOfDirector(int dateOfDirector) {
		this.dateOfDirector = dateOfDirector;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public int getYrofRelease() {
		return yrofRelease;
	}
	public void setYrofRelease(int yrofRelease) {
		this.yrofRelease = yrofRelease;
	}
	@Override
	public String toString() {
		return "Video [dateOfDirector=" + dateOfDirector + ", genre=" + genre + ", yrofRelease=" + yrofRelease + "]";
	}
}
