package Lab2;

public class MediaItem extends Item{

	private int dateOfRuntime;

	public int getDateOfRuntime() {
		return dateOfRuntime;
	}

	public void setDateOfRuntime(int dateOfRuntime) {
		this.dateOfRuntime = dateOfRuntime;
	}

	@Override
	public String toString() {
		return "MediaItem [dateOfRuntime=" + dateOfRuntime + "]";
	}
}
