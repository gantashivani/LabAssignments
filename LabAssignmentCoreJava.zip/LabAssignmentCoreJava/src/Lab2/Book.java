package Lab2;

public class Book  extends WrittenItem{

}
