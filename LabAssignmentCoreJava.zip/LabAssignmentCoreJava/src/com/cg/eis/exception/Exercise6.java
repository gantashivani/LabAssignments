package com.cg.eis.exception;
import java.util.Scanner;
@SuppressWarnings("serial")
class EmployeeException extends Throwable{
	public EmployeeException(String errorMsg){		
			super(errorMsg);
	}
}
public class Exercise6 {
	static void validation(int salary) throws  EmployeeException
	{
		if(salary<3000)
			throw new EmployeeException("less salary");	
		else		
		   System.out.println("Salary is "+salary);
	}
	@SuppressWarnings("resource")
	public static void main(String[] args)throws EmployeeException {
		
		Scanner sc=new Scanner(System.in);
		int marks=sc.nextInt();
		Exercise6.validation(marks);
	}
}
