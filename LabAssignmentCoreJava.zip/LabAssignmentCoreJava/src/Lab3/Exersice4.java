package Lab3;

import java.util.Scanner;

public class Exersice4 {
		
		void charCount(String a)
		{
			char[] b = a.toCharArray();
			
			int count=0;
			for(int i=0;i<a.length();i++)
			{
				if(b[i]=='@')
				{
					continue;
				}
			for(int j=i;j<a.length();j++)
			{
				char x=a.charAt(i);
			if(x == b[j]){
				count++;
				b[j]='@';
			}
			}
			System.out.println(a.charAt(i)+"="+count);
			count=0;
			}
		}
	
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		Exersice4 e=new Exersice4();
		e.charCount(s);
	}
}
