package Lab3;

import java.util.Scanner;

public class Exersice3 {
	void ReverseArray(int a[],int order)
	{
		int temp;
		//sorting
		for(int i=0;i<order;i++)
		{
			for(int j=i+1;j<order;j++)
			{
				if(a[i]<a[j]){
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
				}
			}
		}
		System.out.println("sorted array");
		for(int i=0;i<order;i++)
		{
			System.out.println(a[i]);
		}
		//String snum=a.toString();
		
	}

	@SuppressWarnings("resource")
	public static void main(String[] args)
	{
		int i;
		System.out.println("enter order");
		Scanner sc=new Scanner(System.in);
		int norder=sc.nextInt();
		int a[]=new int[norder];
		System.out.println("enter numbers");
		for(i=0;i<norder;i++)
		{
			a[i]=sc.nextInt();
		}
		
		Exersice3 e=new Exersice3();
		e.ReverseArray(a,norder);
		
	}
}
