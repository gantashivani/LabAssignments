package Lab3;
import java.util.Scanner;
public class Exersice2 {
	void sortedArray(String a[],int order)
	{
		String temp;
		for(int i=0;i<order;i++)
		{
			for(int j=i+1;j<order;j++)
			{
				if(a[i].compareTo(a[j])>0){
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
				}
			}
		}
		int i=0;
		while(i<order)
		{
			if(order%2==0){
				for(i=0;i<=((a.length)/2);i++){
					a[i]=a[i].toUpperCase();
				}
				for(i=((a.length)/2);i<a.length;i++){
					a[i]=a[i].toLowerCase();
				}
			}
			else{
				for(i=0;i<=(((a.length)/2)+1);i++){
					a[i]=a[i].toUpperCase();
				}
				for(i=(((a.length)/2)+1);i<a.length;i++){
					a[i]=a[i].toLowerCase();
				}
			}
		}
		for(int k=0;k<order;k++)
		{
			System.out.print(a[k]+" ");
		}
	}
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		System.out.println("Enter Order");
		Scanner sc=new Scanner(System.in);
		int sOrder=sc.nextInt();
		String[] strArray=new String[sOrder];
		System.out.println("Enter Elements");
		for(int i=0;i<sOrder;i++)
		{
			strArray[i]=sc.next();
		}
		Exersice2 e=new Exersice2();
		e.sortedArray(strArray, sOrder);
	}	
}
