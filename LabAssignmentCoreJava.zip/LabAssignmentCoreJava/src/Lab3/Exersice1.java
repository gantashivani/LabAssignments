package Lab3;

import java.util.Scanner;

public class Exersice1 {
	int getSecondSmallest(int a[])
	{
		int temp;
		for(int j=0;j<a.length;j++)
		{
			for(int k=j;k<a.length;k++)
			{
			if(a[j]>a[k])
			{
				temp =a[j];
				a[j]=a[k];
				a[k]=temp;
			}
		}
	}
		return a[1];
	}
	@SuppressWarnings("resource")
	public static void main(String[] args) {

		int i;
		System.out.println("enter order");
		Scanner sc=new Scanner(System.in);
		int aOrder=sc.nextInt();
		int a[]=new int[aOrder];
		System.out.println("enter elements");
		for(i=0;i<aOrder;i++)
		{
			a[i]=sc.nextInt();
		}
		Exersice1 e=new Exersice1();
		System.out.println("the second smallest no. is ");
		System.out.println(e.getSecondSmallest(a));
	}
}