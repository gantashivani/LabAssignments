package Lab4;
import java.util.Scanner;
public class Exersice1 {
	int cubeSum(int n)
	{
		int sum=0,r;
		while(n>0)
		{
			r=n%10;
			sum=sum+(r*r*r);
			n=n/10;
		}
		return sum;
	}
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		System.out.println("Enter number");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Exersice1 x=new Exersice1();
		System.out.println(x.cubeSum(n));
	}
}
