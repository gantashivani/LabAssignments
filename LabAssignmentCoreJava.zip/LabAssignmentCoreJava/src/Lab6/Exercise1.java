package Lab6;

import java.util.Scanner;
import java.util.StringTokenizer;

class StringTokenizerEg{
	int sumAll(StringTokenizer s)
	{
		int n,sum=0;
		while(s.hasMoreElements())
		{
			
			n=Integer.parseInt(s.nextToken());
			System.out.println(n);
			sum+=n;
		}
		return sum;
	}
}
public class Exercise1 {

	@SuppressWarnings("resource")
	public static void main(String[] args)
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Data");
	String s=sc.nextLine();
	StringTokenizer st=new StringTokenizer(s," ");//delimiter here is space
	StringTokenizerEg e=new StringTokenizerEg();
	System.out.println(e.sumAll(st));
	}	
}
