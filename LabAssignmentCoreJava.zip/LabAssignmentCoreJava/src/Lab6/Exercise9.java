package Lab6;

import java.util.Date;
import java.util.Scanner;

public class Exercise9 {

	@SuppressWarnings({ "deprecation", "resource" })
	public static void main(String[] args) {
		
		System.out.println("Enter Date");
		Scanner sc=new Scanner(System.in);
		int day=sc.nextInt();
		System.out.println("Enter Month");
		int mon=sc.nextInt();
		System.out.println("Enter Year");
		int yr=sc.nextInt();
		Date date=new Date(yr,mon,day);
		System.out.println(date);
		System.out.println("Current System Date");
		Date sysdate=new Date();
		System.out.println(sysdate);
		

	}

}
