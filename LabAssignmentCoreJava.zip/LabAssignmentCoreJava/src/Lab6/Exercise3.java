package Lab6;

import java.util.Scanner;

public class Exercise3 {
	
	String getImage(String data)
	{
	StringBuilder reversedata=new StringBuilder(data) ;
	reversedata.reverse();
	String rData=reversedata.toString();
	return rData;
	}
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		System.out.println("input string");
		Scanner sc=new Scanner(System.in);
		String data=sc.next();
		Exercise3 e=new Exercise3();
		System.out.print(data+"|"+e.getImage(data));
	}
}
