package Lab10;

import java.util.Scanner;

@FunctionalInterface
interface PowerOf{
	double powerOf(double a,double b);
}
public class Exersice1 {	
	@SuppressWarnings("resource")
	public static void main(String[] args){
		System.out.println("enter base value:");
		Scanner sc=new Scanner(System.in);
		double x=sc.nextInt();
		System.out.println("enter power value:");
		double y=sc.nextInt();
		
		PowerOf p=(a,b)->{ return Math.pow(x,y);};
		System.out.println(p.powerOf(x, y));
		
	}
}
