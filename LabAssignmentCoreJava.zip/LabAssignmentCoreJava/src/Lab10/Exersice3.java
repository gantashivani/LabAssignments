package Lab10;

@FunctionalInterface
interface Test{
	boolean verify(String user,String password);
}
public class Exersice3 {
	public static void main(String[] args) {
		
		String name="capgemini";
		String pass="cg13";
		Test t=(user,password)->{if(user.equals("capgemini")&& password.equals("cg123"))
									return true;
								else return false;};
		
		System.out.println(t.verify(name, pass));
	}

}
