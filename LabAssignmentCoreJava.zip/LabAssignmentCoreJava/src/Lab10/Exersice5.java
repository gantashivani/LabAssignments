package Lab10;

import java.util.Scanner;

interface Fact
{
	int factorial(int num);
}
public class Exersice5 {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		
		System.out.println("Enter number");
		Scanner sc=new Scanner(System.in);
		int number=sc.nextInt();
		Fact f=(num)->{int fac=1;
		for(int i=1;i<=num;i++)
				fac=fac*i;
		return fac;
	};
	System.out.println(f.factorial(number));
}
}