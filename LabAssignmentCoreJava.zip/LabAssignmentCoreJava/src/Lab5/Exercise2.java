package Lab5;

import java.util.Scanner;

public class Exercise2 {

	void fibonacciNonR(int a[],int n)
	{
		for(int i=2;i<n;i++)
		{
			a[i]=a[i-1]+a[i-2];
		}
		for(int i=0;i<n;i++)
			System.out.print(a[i]+"  ");
	}
	
	 int fibonacciR(int a[],int n)
	{
		if(n==0)
			return 0;
		else if(n==1)
			return 1;
		else 
			return (fibonacciR(a,n-1)+fibonacciR(a,n-2));
	}
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		
		Exercise2 e=new Exercise2();
		System.out.println("Enter length of sequence");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int a[]=new int[n];
		a[0]=1;
		a[1]=1;
		System.out.println("without recursion");
		e.fibonacciNonR(a, n);
		System.out.print("\nwith recursive  the "+n+"th term will be:");
		System.out.println(e.fibonacciR(a,n));
	}
}
