package Lab5;

@SuppressWarnings("serial")
class ValidName extends Throwable{
	public ValidName(String errorMsg){		
			super(errorMsg);
	}
}
public class Exercise4 {
	String firstName="Shivani";
	String lastName="Ganta";
	static void validation(String firstName,String lastName) throws  ValidName
	{
		if(firstName.equals("") && lastName.equals("") )
			throw new ValidName("Enter valid name details");	
		else		
		   System.out.println("Valid Name");
	}
	public static void main(String[] args)throws ValidName {
		
		String firstName1="";
		String lastName1="";
		Exercise4.validation(firstName1,lastName1);
		System.out.println("rest............");
	}
}
