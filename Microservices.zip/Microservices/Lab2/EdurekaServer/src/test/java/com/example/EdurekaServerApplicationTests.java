package com.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
