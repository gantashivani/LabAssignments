package com.cg.employee.update.service;

import com.cg.employee.update.entity.Employee;

public interface EmployeeService  {

	Employee updateEmp(Employee emp);

}
