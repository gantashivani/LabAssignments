package com.cg.employee.add;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeAddApplicationTests {

	@Test
	void contextLoads() {
	}

}
