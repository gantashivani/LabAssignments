package com.cg.employee.add.service;

import com.cg.employee.add.entity.Employee;

public interface EmployeeService {

	Employee addEmp(Employee emp);

}
