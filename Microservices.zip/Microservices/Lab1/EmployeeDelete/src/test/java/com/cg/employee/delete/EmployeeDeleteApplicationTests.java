package com.cg.employee.delete;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeDeleteApplicationTests {

	@Test
	void contextLoads() {
	}

}
