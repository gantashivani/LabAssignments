package com.cg.employee.delete.service;

public interface EmployeeService {

	String deleteEmp(Integer id);

}
